// postcss.config.js
module.exports = {
    plugins: {
      tailwindcss: {}, // Tailwind CSS를 활성화합니다.
      autoprefixer: {}, // CSS에 자동으로 벤더 접두사를 추가합니다.
    },
  }
  