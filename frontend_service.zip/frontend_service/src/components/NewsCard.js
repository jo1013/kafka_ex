import React from 'react';
import { Link } from 'react-router-dom';

function NewsCard({ id, title, imageUrl }) {
  // 이미지가 없는 경우 기본 이미지를 배경으로 사용하도록 설정합니다.
  const backgroundImageUrl = imageUrl ? imageUrl : 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAMFBMVEX///+zs7OwsLCtra36+vq7u7vLy8vb29vl5eXDw8PR0dHu7u7y8vLX19e/v7/g4OD6ePxCAAAEsElEQVR4nO2b23akIBAABfE6Xv7/b1dowMaJOXuyu6PuqXpIBjWGSiMgdKoKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOBOuF5I5VdRCke6dhiGdlzd52v3N+hr66m7WG5DeZfpGl82xn8ZXtfU8c/ot9oHotRoVaFySzrtsXa8rJ4/JxnaVsqFobPpbPo+XFfTn5JjaOXh04YunjFL2za2+EM8iH5vhkFLG7ZWpKZwoTja/pub3ZLdUB4yZTjZImoxostlVf0hKoa1j5UylI9mv7QOxk/rUIOhlfbow6MMmyA079c2e6gfhBhOQ6h8pw2dzYGNzOHI07rTYFi/pjp2NrvhKx0qrzXNZXX9GdFQzLZeZTd893l3fgLJsJLOpv+PDaNQ+52hfbRhNagpqJeQR1NNwqs197hPYjecDoaxL1XDnzyrD+1L/cf5MIFbjsOfOQ6Qj0AZVmUMo/HeTDspTyd3uivaUKZl2VAmojY9d9LPPK6RFobxZSJ3lzGITb8V3SxnHhfC0tAVMdyexPhSmL+YvNrxHArD+KjtQ16xiOEvfFo3Ux0N5fVBDeqjVY7WrNdU8o/oa082fIWiGuZfrZHVOFs388NmMxHnORQLE/da53Hs+sd1MQAAAAAAcG8O7x6X4lrNqg+pbAs5oPd2Vzn0vmLhusGEN0gzdOltqvwlG59cB3BWUYeVTxezS/LbujNyQNdLDllzuN001PmVf/uJRe4x1bbkk6txTq+x2GgopbwfEdeBrQpY3IExdbln39njqk04P9Xl0Y9uMDrJ9ol/88Iw1z6uzGjDtKhYRmOu053SXe2Xhp+N4TiOUt1m+xDqkwzTBkvOp1GGe5D0tkwd/dqu77s25Eldb+iRJpd/azaM29dLqtduqNIz9oMu5dMk6W6TVYYX7kidGUoWyZ4wtMuEbTZpvPvuoeyc6m0Z19b3NpRF0fbd0EkxnMmpJa7MrRHW0AzuaehTL3zf6kt2KA3Durd1YZsm76315/tO0dBl/rXRka8MrfQ/LoRwEaVsuMSQSDON9Z3Pt39jT1Mn7L82OvK1oY+JXavQIZaGr1SSZhoHFSnIeOPKcL2Nhx8WPDEMw+ASIiPxyYaylT3F3cT05KmWvB662rsapl2m7WNpaHJzbHJ/9DuGedJ2F8M0oduiVRhK5EJBoimTT9VKvzZsusyHBc8MU/LoUJWGknPSvzZ0csm4p7StdZoKasObjRbeMKbL9KVhmrqETlH6yDBCrHuy0LSuaz88wFBGBT9p0YZdboK5KaoJ+z6ktPYBhr61hW15bbgcBVPfOJRD/iMMK/+vI77ZKcPpLYRpSIwT2HJ8vN7QbU+MzEaafl3DHFMZJpRh6j7jeD7HlExPnMHWw+rPvBmaIfPJJOKzN+AzQyd5znlmmfNqPSn1ZLtj07z1peZeqxhnhjIYqhqKcVzTGY6Tl5M5zZ0NQ9vTqzNzkY24GrVSswWruf4d3zWa8PbqTP6Y6MLZLl2+6MyMcHWTj6xDGCutT7Xt49HJNCXP+7eakslPd6b7rAkDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANyaXw8SIvHRAp11AAAAAElFTkSuQmCC';

  return (
    <Link to={`/news/${id}`} className="block no-underline text-current">
      <div className="overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300 ease-in-out">
        <div
          className="newsImage bg-cover bg-center h-48 w-full"
          style={{ backgroundImage: `url(${backgroundImageUrl})` }}
        ></div>
        <div className="newsContent p-4">
          <h3 className="font-semibold text-lg text-gray-800">{title}</h3>
        </div>
      </div>
    </Link>
  );
}

export default NewsCard;
