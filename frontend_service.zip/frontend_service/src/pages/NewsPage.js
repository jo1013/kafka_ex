import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import NewsCard from '../components/NewsCard';
import { fetchNews } from '../api/newsApi';

function NewsPage() {
    const [newsData, setNewsData] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(0);
    const [error, setError] = useState(null);
    const itemsPerPage = 10;
    const navigate = useNavigate(); 
    const [pageRange, setPageRange] = useState({ start: 1, end: 10 });
    
    useEffect(() => {
        const loadData = async () => {
            try {
                const data = await fetchNews(currentPage, itemsPerPage);
                if (data && data.newsList && Array.isArray(data.newsList)) {
                    setTotalPages(Math.ceil(data.totalItems / itemsPerPage));
                    setNewsData(data.newsList);
                }
            } catch (e) {
                setError(`데이터 로딩 중 오류 발생: ${e.message}`);
            }
        };
        loadData();
    }, [currentPage]);

    const handlePageClick = (page) => {
        setCurrentPage(page);
    };
    const handleLogout = () => {
        localStorage.removeItem('userToken');
        navigate('/login');
    };
    const handleNext = () => {
        setPageRange(prevRange => {
            const newEnd = Math.min(prevRange.end + 10, totalPages);
            return {
                start: prevRange.end + 1,
                end: newEnd
            };
        });
    };
    const handlePrevious = () => {
        setPageRange(prevRange => {
            const newStart = Math.max(prevRange.start - 10, 1);
            return {
                start: newStart,
                end: newStart + 9
            };
        });
    };

    return (
        <div className="max-w-screen-xl mx-auto px-4">
            <h1 className="text-4xl font-bold text-center my-8">실시간 뉴스 피드 시스템</h1>
            <button className="mb-4 py-2 px-4 bg-blue-500 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition-colors" onClick={handleLogout}>로그아웃</button>
            {error && <p className="text-red-500 text-center">{error}</p>}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {newsData.map((news) => (
    <Link to={`/news/${news._id}`} key={news._id} className="no-underline text-current">
        <NewsCard id={news._id} title={news.title} imageUrl={news.image} />
    </Link>
))}

            </div>
            <div className="flex justify-center items-center my-8 space-x-2">
                {pageRange.start > 1 && (
                    <button className="py-2 px-4 bg-gray-300 text-gray-800 font-semibold rounded-lg shadow-md hover:bg-gray-400 transition-colors" onClick={handlePrevious}>이전</button>
                )}
                {Array.from({ length: Math.min(10, totalPages - pageRange.start + 1) }, (_, i) => pageRange.start + i).map(page => (
                    <button key={page} className={`py-2 px-4 ${currentPage === page ? 'bg-blue-500' : 'bg-gray-300'} text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition-colors`} onClick={() => handlePageClick(page)}>
                        {page}
                    </button>
                ))}
                {pageRange.end < totalPages && (
                    <button className="py-2 px-4 bg-gray-300 text-gray-800 font-semibold rounded-lg shadow-md hover:bg-gray-400 transition-colors" onClick={handleNext}>다음</button>
                )}
            </div>
            <p>현재 페이지: {currentPage}</p>
        </div>
    );
};

export default NewsPage;
